"use strict";

// Variable/Object declaration and initialization - Start
const isDebug = false;
const DELAY = 2000;
var gameOver = false;
$(".rules").hide();

// tingle model popup
var modalTinyNoFooter = new tingle.modal();

const deck = {
    cards: []
}

var tempCard;
const player = {
    cards: [],
    handValue: 0,
    isWinner: false,
    canHit: true,
    hasAce: false
}

const dealer = {
    cards: [],
    handValue: 0,
    isWinner: false,
    canHit: true,
    hasAce: false
}

var result = document.getElementById("gameResult");

const cardSuit = ["hearts", "diams", "clubs", "spades"];
const cardFace = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"];

$(".checkmarkDealer").hide();
$(".checkmarkPlayer").hide();
$("#handValueDealer").hide();
//Variable/Object declaration and initialization - End


// var x = document.getElementById("myAudio"); 

// function playAudio() { 
//   x.play(); 
// } 

const init = () => {
    document.getElementById("oneDeck").innerHTML = "";

    player.cards = [];
    player.handValue = 0;
    player.isWinner = false;

    dealer.cards = [];
    dealer.handValue = 0;
    dealer.isWinner = false;
    
    $("#containerPlayer").removeClass("winner");
    $("#containerDealer").removeClass("winner");    
    $(".checkmarkPlayer").hide();
    $(".checkmarkDealer").hide();

    // Clear all the child elements except the first element - Start
    debugger
    // Jquery apporoach    
    $("#cardContainerPlayer > *").slice(1).remove();

    // Pure JS approach
    // var myNode = document.getElementById("cardContainerPlayer");

    // var fc = myNode.firstChild;
    // var sib = fc && fc.nextSibling;
    // while (myNode.lastChild && myNode.lastChild !== sib) {
    //     myNode.removeChild(myNode.lastChild);
    // }

    // Jquery apporoach
    $("#cardContainerDealer > *").slice(1).remove();

    // Pure JS approach
    // var myNodeDealer = document.getElementById("cardContainerDealer");
    // var fcDealer = myNodeDealer.firstChild;
    // var sib = fcDealer && fcDealer.nextSibling;
    // while (myNodeDealer.lastChild && myNodeDealer.lastChild !== sib) {
    //     myNodeDealer.removeChild(myNodeDealer.lastChild);
    // }
    // Clear all the child elements except the first element - End    

    document.getElementById("playerCards").innerHTML = "";
    document.getElementById("dealerCards").innerHTML = "";
}

if (!isDebug) {
    document.getElementById("btnDevelopment").style.display = "none";
    document.getElementById("deck").style.display = "none";
    document.getElementById("oneDeck").style.display = "none";
    document.getElementById("playerCards").style.display = "none";
    document.getElementById("dealerCards").style.display = "none";    
} else {
    document.getElementById("btnDevelopment").style.display = "block";
    document.getElementById("deck").style.display = "block";
    document.getElementById("oneDeck").style.display = "block";
    document.getElementById("playerCards").style.display = "block";
    document.getElementById("dealerCards").style.display = "block";

    // Show template card
    document.getElementById("templatePlayer").style.display = "block";
    document.getElementById("templateDealer").style.display = "block";        
}

const help = () =>{
     //Implement tingle.js for better popup message.                    
     showPopup(`<h1>Test</h1>`);
}

const showPopup = (content) => {
    debugger;
    modalTinyNoFooter.open();
    // $(".rules").show();
    modalTinyNoFooter.setContent(document.querySelector('.tingle-demo-big').innerHTML);
    // modalTinyNoFooter.setContent(content);

}

const showGameButtons = (cardDealt) => {
    if (cardDealt) {
        $("#btnDeal").hide();
        $("#btnHit").show();
        $("#btnStand").show();
    } else {
        $("#btnDeal").show();
        $("#btnHit").hide();
        $("#btnStand").hide();
    }

    if (player.isWinner === true) {
        document.getElementById("containerDealer").classList.remove("winner");
        document.getElementById("containerPlayer").classList.add("winner");

        $("#handValueDealer").show();
        $(".checkmarkPlayer").show();
        $(".checkmarkDealer").hide();
    } else if (dealer.isWinner === true) {
        document.getElementById("containerPlayer").classList.remove("winner");
        document.getElementById("containerDealer").classList.add("winner");

        $("#handValueDealer").show();
        $(".checkmarkPlayer").hide();
        $(".checkmarkDealer").show();
    } else {
    }
}
showGameButtons(false);



// In JavaScript, functions are objects.
// You can work with functions as if they were objects.
function card(suit, face) {
    this.suit = suit;
    this.face = face;

    switch (face) {
        case "A":
            this.faceValue = 11;
            break;
        case "J":
        case "Q":
        case "K":
            this.faceValue = 10;
            break;
        default:
            this.faceValue = parseInt(face);
            break;
    }
};

const createDeck = () => {
    deck.cards = [];
    deck.cards.length = 0;
    cardSuit.forEach(function (suit) {
        cardFace.forEach(function (face) {
            deck.cards.push(new card(suit, face));
        });
    });
}

const shuffleDeck = () => {
    // Fisher–Yates shuffle algorithm
    let temp, i, rnd;
    for (i = 0; i < deck.cards.length; i++) {
        rnd = Math.floor(Math.random() * deck.cards.length);
        temp = deck.cards[i];
        deck.cards[i] = deck.cards[rnd];
        deck.cards[rnd] = temp;
    }
}

const newDeck = () => {
    init();
    createDeck();
    shuffleDeck();

    document.getElementById("oneDeck").innerHTML = JSON.stringify(deck);
}

const burnOneCard = () => {
    // Remove the top deck to burn
    deck.cards.splice(0, 1);
}

const showDeck = () => {
    document.getElementById("oneDeck").innerHTML = JSON.stringify(deck);
}
function nothing(){

}
const dealOneCardToPlayer = (x, isHit) => {
    // return new Promise(function (resolve) {
    //     setTimeout(function () {
    // Take a card from the top deck to be assigned to tempcard.
    tempCard = deck.cards.splice(0, 1);

    //console.log(tempCard[0].face);
    //console.log(tempCard[0].faceValue);

    player.cards.push(tempCard);

    //console.log(player.handValue);

    if(tempCard[0].face === "A"){
        player.hasAce = true;
    }

    player.handValue = countHandValue(tempCard[0], player, isHit);
    document.getElementById("handValuePlayer").innerHTML = player.handValue;

    // conditional (ternary) operator
    player.canHit = player.cards.length === 5 ? false : true

    if (player.canHit) {
        $("#btnHit").show();
    } else {
        $("#btnHit").hide();
    }

    //player.cards.push(new card("Spades","A"));
    //player.cards.push(new card("Spades","10"));
    document.getElementById("playerCards").innerHTML = JSON.stringify(player);


    makeCardPlayer(tempCard[0]);

    

    //         resolve();
    //     }, DELAY);
    // });

}



const dealOneCardToDealer = (holeCard, isHit) => {
    // return new Promise(function (resolve) {
    //     setTimeout(function () {
    // Take a card from the top deck to be assigned to tempcard.
    tempCard = deck.cards.splice(0, 1);

    //console.log(tempCard[0].face);
    //console.log(dealer.handValue);

    if(tempCard[0].face === "A"){
        dealer.hasAce = true;
    }

    dealer.handValue = countHandValue(tempCard[0], dealer, isHit);
    document.getElementById("handValueDealer").innerHTML = dealer.handValue;
    

    dealer.cards.push(tempCard);

    //dealer.handValue = countHandValue(tempCard[0]);    

    // conditional (ternary) operator
    dealer.canHit = dealer.cards.length === 5 ? false : true
    
    if (dealer.canHit) {
        $("#btnHit").show();
    } else {
        $("#btnHit").hide();
    }

    document.getElementById("dealerCards").innerHTML = JSON.stringify(dealer);


    makeCardDealer(tempCard[0], holeCard);


    //         resolve();
    //     }, DELAY);
    // });        
}

const countAllHandValue = (cardsOnHand) => {
    console.log(cardsOnHand[0][0]);
    console.log(cardsOnHand[1][0]);
    console.log(cardsOnHand.length);

    let sum = 0;
    for (let i = 0; i < cardsOnHand.length; i++) {
        sum += cardsOnHand[i][0].faceValue;
    }
    
    return sum;
}

const countHandValue = (onecard, person, isHit) => {
    if(isHit){        
        // Only can cover one Ace for this solution. More than one Ace will be a bug.
        if (person.handValue > 10 && person.hasAce === true) {
            person.cards.forEach(card => {
                //console.log(card[0]);
                if (card[0].face === 'A') card[0].faceValue = 1;
                return card[0];
            });
            person.handValue = countAllHandValue(person.cards);
            // loop through all the Ace and transform all Ace's face value from 11 to 1
            // Recalculate all the cards on hand again.          
        } else {
            person.handValue = person.handValue + onecard.faceValue;            
        }
    } else {
        person.handValue = person.handValue + onecard.faceValue;
    }
    

    //console.log(person.handValue);
    //console.log(onecard);

    return person.handValue;
}

const showHandValue = () => {
    document.getElementById("playerCardsHandValue").innerHTML = player.handValue;
    document.getElementById("dealerCardsHandValue").innerHTML = dealer.handValue;
}

const getDeckCardCount = () => {
    document.getElementById("deckCardCount").innerHTML = deck.cards.length;
}

const checkGameOver = () => {
    if (gameOver) {
        $(".holeCard > :nth-child(1)").show();
        $(".holeCard > :nth-child(2)").show();

        $(".holeCard").removeClass("holeCard");
        $("#handValueDealer").show();

        showGameButtons(false);
    }
}

const checkEndGame1 = () => {
    gameOver = true;
    if (player.handValue === 21 && dealer.handValue !== 21) {
        result.innerHTML = "BlackJack! Player won.";
        player.isWinner = true;
    } else if (player.handValue !== 21 && dealer.handValue === 21) {
        result.innerHTML = "BlackJack! Dealer won.";
        dealer.isWinner = true;
    } else if (player.handValue === 21 && dealer.handValue === 21) {
        result.innerHTML = "Push.";
    } else {
        gameOver = false;
    }
}

const checkEndGame2 = () => {
    if (player.cards.length <= 5 && player.handValue > 21) {
        result.innerHTML = "Bust! Dealer won.";
        dealer.isWinner = true;
        gameOver = true;
    }
}

const checkEndGame3 = () => {

    if (player.cards.length <= 5 && dealer.cards.length <= 5) {
        // Check bust
        if (player.handValue <= 21 && dealer.handValue > 21) {
            result.innerHTML = "Bust! Player won.";
            player.isWinner = true;
        } else if (player.handValue === 21 && dealer.handValue !== 21) {
            result.innerHTML = "BlackJack! Player won.";
            player.isWinner = true;
        } else if (player.handValue !== 21 && dealer.handValue === 21) {
            result.innerHTML = "BlackJack! Dealer won.";
            dealer.isWinner = true;

        } else if (player.handValue === dealer.handValue) {
            result.innerHTML = "Push.";
        } else if (player.handValue > dealer.handValue) {
            result.innerHTML = "Player won.";
            player.isWinner = true;
        } else if (player.handValue < dealer.handValue) {
            result.innerHTML = "Dealer won.";
            dealer.isWinner = true;
        } else {
            result.innerHTML = "Error";
        }
    } else {
        result.innerHTML = "Error";
    }
    gameOver = true;
}

// This function use JQuery lib
function makeCardPlayer(_card) {
    setTimeout(function(){
// .card is created in the template card css class
var card = $(".card.templatePlayer").clone();

if(!isDebug){
    card.removeClass("templatePlayer");
}

// .cardFace is created in the template card css class
// It will search for this css class and add the content aka innerHTML
card.find(".playerCardFace").html(_card.face);

// .suit is created in the template card css class
// It will search for this css class and add the content aka innerHTML
card.find(".playerCardSuit").html("&" + _card.suit + ";");
// &spades; -> ♠, &clubs; -> ♣, &hearts; -> ♥, &diams; -> ♦
// more char, https://www.w3schools.com/charsets/ref_utf_symbols.asp

// hearts and diamonds are red color. otherwise, default black color.
if (_card.suit === "hearts" || _card.suit === "diams") {
    card.addClass("red");
}

// Append generated card to the container
$("#cardContainerPlayer").append(card);
    },DELAY);
    
}

// This function use JQuery lib
function makeCardDealer(_card, _holeCard) {
    setTimeout(function(){
// .card is created in the template card css class
var card = $(".card.templateDealer").clone();

if(!isDebug){
    card.removeClass("templateDealer");
}

// .cardFace is created in the template card css class
// It will search for this css class and add the content aka innerHTML
card.find(".dealerCardFace").html(_card.face);

// .suit is created in the template card css class
// It will search for this css class and add the content aka innerHTML
card.find(".dealerCardSuit").html("&" + _card.suit + ";");
// &spades; -> ♠, &clubs; -> ♣, &hearts; -> ♥, &diams; -> ♦
// more char, https://www.w3schools.com/charsets/ref_utf_symbols.asp

// hearts and diamonds are red color. otherwise, default black color.
if (_card.suit === "hearts" || _card.suit === "diams") {
    card.addClass("red");
}

if (_holeCard) {
    card.addClass("holeCard");
}

// Append generated card to the container
$("#cardContainerDealer").append(card);

// Hide the hole card Suit and Face span
$(".holeCard > :nth-child(1)").hide();
$(".holeCard > :nth-child(2)").hide();
    },DELAY);
    

}

const deal = () => {
    newDeck();

    // Option: to burn first card before deal a card
    // to the first player
    burnOneCard;

    // dealOneCardToPlayer()
    //     .then(dealOneCardToDealer)
    //     .then(dealOneCardToPlayer)
    //     .then(dealOneCardToDealer(true));

    dealOneCardToPlayer("",false);
    dealOneCardToDealer(false,false);
    dealOneCardToPlayer("",false);

    // true for hole card
    dealOneCardToDealer(true,false);

    showGameButtons(true);
    checkEndGame1();
    checkGameOver();
}

const hit = () => {
    dealOneCardToPlayer("", true);    
    checkEndGame2();
    checkGameOver();
}

const stand = () => {
    // Simple AI to automate dealer's decision to hit or stand
    if (dealer.handValue >= 17) {
        checkEndGame3();
    } else {
        // Hit until dealer's hand value is more than 16
        while (dealer.cards.length < 5 && dealer.handValue < 17) {
            dealOneCardToDealer(false, true);
            checkEndGame3();
        }
    }
    checkGameOver();
}